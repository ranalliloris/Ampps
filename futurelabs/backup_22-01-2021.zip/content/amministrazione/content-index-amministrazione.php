<?php
    if($reserved==false || $auth==false)
    {
        require_once "content/not-authorized.php";
    }
    else
    {
?>
<div id="content">
    <a class="btn btn-primary btn-lg btn-block col-lg-6 mx-auto" href="./controller.php?path=amministrazione&service=content-scarica-csv.php">Scarica CSV Iscrizioni</a><br>
    <a class="btn btn-primary btn-lg btn-block col-lg-6 mx-auto" href="logout.php">Logout</a> <br>
</div>
<?php
    } //CHIUSO ELSE
?>