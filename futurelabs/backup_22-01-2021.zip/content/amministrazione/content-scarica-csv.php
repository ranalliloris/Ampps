
<form id="form-ricerca">
    <div id="error-cmdline" class="d-print-none">
        <p class="req" id="error"></p>
        <p class="text-center" id="pulsanti">
            <a href="./controller.php?path=amministrazione&service=content-index-amministrazione.php" class="btn btn-primary" id="btn-home">Torna alla Home</a>
            <a href="" class="btn btn-primary" id="btn-csv">Scarica CSV</a>
        </p>
    </div>

        <div id="dati-ricerca">
            <div class="row mb-2">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Dati Iscrizioni</h5>
                            <div id="card-dati-ricerca">
                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
</form>

<script src="csv-export/src/table2csv.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>
<script src="js/amministrazione/csv.js?<?php echo filemtime("js/amministrazione/csv.js"); ?>"></script>