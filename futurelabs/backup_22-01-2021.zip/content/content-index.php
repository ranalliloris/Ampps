<div id="content">
    <p id="msgbenvenuto">Benvenuti nel Sistema di Iscrizione ai corsi Future Labs dell'IIS Leonardo Da Vinci<p>
    <a id="btn-registrazione" class="btn btn-primary btn-lg btn-block col-lg-6 mx-auto" href="./controller.php?path=corsi&service=content-iscrizione-persona.php">Iscrizione Corsi</a><br>
    <a id="btn-modifica-iscrizione" class="btn btn-primary btn-lg btn-block col-lg-6 mx-auto" href="./controller.php?path=corsi&service=content-modifica-iscrizione.php">Visualizza la tua iscrizione</a><br>
</div>