<div id="content">
    <p id="msgbenvenuto">Benvenuti nel Sistema di Iscrizione ai corsi Future Labs dell'IIS Leonardo Da Vinci<p>
    <div class="row">

        <div class="col-12 alert alert-danger">
            <h2 class="text-center">SITO IN MANUTENZIONE! LE ISCRIZIONI RIAPRIRANNO A BREVE</h2>
        </div>
    </div>
</div>