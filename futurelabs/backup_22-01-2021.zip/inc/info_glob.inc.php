<?php
    //$hostDB="31.11.39.30"; //indirizzo ip del DB 89.46.111.209
    $hostDB="localhost";
    $nameDB="Sql1509550_1";
    $userDB="Sql1509550";
    $passwDB="06d1210i52";
    $data_inizio_iscrizioni="18/01/2021";
    $data_fine_iscrizioni="18/02/2021";
    $numMaxCorsiIsc=5;
?>