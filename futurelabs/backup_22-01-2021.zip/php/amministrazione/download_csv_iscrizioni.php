<?php
   session_start();
   require_once (__DIR__.'/../../inc/info_glob.inc.php');
   include_once (__DIR__.'/../function/funDate.php');
   include_once __DIR__.'/../../classi/connectionDB.php';
   include_once __DIR__.'/../../classi/function.php';
    $dbconn=new dbConnect($hostDB,$userDB,$passwDB,$nameDB);
    $dbconn->connect();
   
    $data_app=$_POST["data-app"];

    
    try
    {
        $stmt=elencoIscrizioni($dbconn);
        $rows=$stmt->fetchAll();
        if(count($rows)>0)
        {
            $i=1;
            $dati["html"].='<div class="table-responsive">
                            <table id="tab-app" class="table text-resize">
                            <thead>
                                <tr class="table-active">
                                    <th scope="col">#</th>
                                    <th scope="col">codice_corso</th>
                                    <th scope="col">nome_corso</th>
                                    <th scope="col">cf</th>
                                    <th scope="col">cognome</th>
                                    <th scope="col">nome</th>
                                    <th scope="col">email</th>
                                    <th scope="col">cellulare</th>
                                    <th scope="col">materia_insegnamento</th>
                                    <th scope="col">classe_concorso</th>
                                    <th scope="col">istituto</th>
                                    <th scope="col">meccanografico</th>
                                </tr>
                            </thead>
                            <tbody>';
            foreach($rows as $row)
            {
                $ora=rtrim($row["ora_inizio"],"0");
                $ora=rtrim($ora,":");
                $dati["html"].='       <tr>
                                <td>'.$i.'</td>
                                <td>'.$row["cod_corso"].'</td>
                                <td>'.$row["corso_nome"].'</td>
                                <td>'.$row["cf"].'</td>
                                <td>'.$row["cognome"].'</td>
                                <td>'.$row["nome"].'</td>
                                <td>'.$row["email"].'</td>
                                <td>'.$row["cellulare"].'</td>
                                <td>'.$row["materia_insegnamento"].'</td>
                                <td>'.$row["classe_concorso"].'</td>
                                <td>'.$row["istituto"].'</td>
                                <td>'.$row["meccanografico"].'</td>
                            </tr>';
                $i++;   

            }
            $dati["html"].= '</tbody>
            </table>';
            $dati["esito"]="success";
        }
        else
        {
            $dati["esito"]="err_data";
            $dati["html"]='<p class="req"> Non sono stati prenotati appuntamenti per questa data </p>';
        }

        
        //throw new Exception(print_r($dati["html"],true));
        $dati["html"]=mb_convert_encoding($dati['html'], 'UTF-8', 'UTF-8');
        $json=json_encode($dati);
        if ($json)
            echo $json;
        else
            echo json_last_error_msg();
    }
    catch(Exception $e)
    {
            $dati["esito"]="err_exc";
            $dati["html"]=$e->getMessage();
            echo json_encode($dati);
    }
?>