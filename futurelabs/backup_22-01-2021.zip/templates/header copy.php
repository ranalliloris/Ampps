<?php
?>
<script src="js/jquery-3.5.1.min.js"></script>
<div  class="container">
    <div class="red-header-line"></div>
        <div id="header">
            <div class="col-xs-12 col-sm-12">
                <p class="logo_scuola float-left">
                    <img class="img-fluid rounded" src="img/logoscuola.png" alt="Istituto Istruzione Secondaria Leonardo Da Vinci">
                </p>
                <h1>
                <span class="school-name">Istituto Statale di Istruzione Superiore
                <br>LEONARDO DA VINCI</span>
                </h1>
                <p class="school-info">Via del Terzolle, 91 - 50127 Firenze • Tel. +3905545961 • Fax +39055412096 • supportodigitale@isisdavinci.eu
                </p>
            </div>
            <h1 class="text-center title-head d-print-none">Iscrizioni Corsi Future Labs</h1>
        </div>