<?php
?>
<script src="js/jquery-3.5.1.min.js"></script>
<div  class="container">
    <div class="red-header-line"></div>
        <div id="header">
            <div class="row">
                <div class="col-xs-12" id="logo-duo">
                    <img class="img-fluid rounded" src="img/LogoDuo.jpg" alt="Future Labs - Istituto Istruzione Secondaria Leonardo Da Vinci">
                </div>
                
                <div class="col-xs-2 col-sm-2" id="logoScuola">
                    <img class="img-fluid rounded" src="img/LogoDaVinci.jpg" alt="Istituto Istruzione Secondaria Leonardo Da Vinci">
                </div>
                <div class="col-xs-8 col-sm-8" id="Intestazione">  
                    <h1 class="school-name">
                    Istituto Statale di Istruzione Superiore
                    LEONARDO DA VINCI
                    </h1>
                    <p class="school-info">Via del Terzolle, 91 - 50127 Firenze • Tel. +3905545961 • Fax +39055412096 • futurelabs@isisdavinci.eu
                    </p>
                </div> 
                <div class="col-xs-2 col-sm-2" id="logoScuola">
                    <img class="img-fluid rounded" src="img/LogoFL.jpg" alt="Istituto Istruzione Secondaria Leonardo Da Vinci">
                </div>
            </div>
            
            <h1 class="text-center title-head d-print-none">Iscrizioni Corsi Future Labs</h1>
        </div>