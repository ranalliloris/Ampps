<?php
class dbConnect
{
    private $host; //contiene l'indirizzo IP del Server DBMS
    private $username; //Username di accesso al DB
    private $password; //Password di accesso al DB
    private $dbName; //Nome del Database al quale vogliamo accedere
    private $db; //Oggetto di connessiona la DB

    public function __construct($host, $username, $password, $dbName) //doppio underscore seguito da construct
    {
        $this->host=$host;
        $this->username=$username;
        $this->password=$password;
        $this->dbName=$dbName;
        $this->db=null;
    }

    public function connect() 
    {
        
    }

    public function close() // viene richiamato direttamente nel codice $dbc.close()
    {
        $this->db=null;
    }

    public function __destruct() //viene richiamato automaticamente al termine dello script che 
                                // usa la classe dbConnect
    {
        $this->db=null;
    }



    

}
?>